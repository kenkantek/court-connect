<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Surface extends Model
{
    protected $table = 'surface';
    protected $fillable = ['name', 'label'];
}
