<?php
namespace App\Repositories\Eloquent\Admin;

use App\Models\Contexts\Court;
use App\Repositories\Interfaces\Admin\CourtInterface;

class CourtRepository implements CourtInterface
{
    public function getDatatableData()
    {
    }

    public function findById($id)
    {
    }

    public function delete($id)
    {

    }

    public function createOrUpdate(Court $court)
    {

    }
}
