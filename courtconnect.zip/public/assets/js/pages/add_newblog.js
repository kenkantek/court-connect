$(document).ready(function() {
    $('.textarea').summernote();
});